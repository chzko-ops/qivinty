﻿-- 1. Хэрэглэгчийн мэдээлэл (дэлгүүр эзэмшигч)
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  full_name text,
  phone text,
  address text,
  is_banned boolean default false,
  deletion_requested boolean default false,
  created_at timestamp default now()
);

-- Admin эрхтэй хэрэглэгчид
create table admin_users (
  user_id uuid references profiles(id) on delete cascade primary key,
  role text default 'admin',
  created_at timestamp default now()
);

-- 2. Дэлгүүрүүд
create table shops (
  id uuid default gen_random_uuid() primary key,
  owner_id uuid references profiles(id) on delete cascade,
  name text not null,
  category text not null,
  description text,
  address text,
  phone text,
  map_url text,
  refund_policy text,
  shipping_policy text,
  return_days integer,
  is_verified boolean default false,
  phone_verified boolean default false,
  email_verified boolean default false,
  social_verified boolean default false,
  schedule jsonb,
  instagram text,
  facebook text,
  tiktok text,
  x_twitter text,
  is_active boolean default true,
  plan text default 'starter',
  trial_ends_at timestamp default (now() + interval '7 days'),
  created_at timestamp default now()
);

-- 3. Бараа бүтээгдэхүүн
create table products (
  id uuid default gen_random_uuid() primary key,
  shop_id uuid references shops(id) on delete cascade,
  name text not null,
  description text,
  price integer not null,
  original_price integer,
  category text,
  emoji text default '🛍',
  image_url text,
  stock_qty integer,
  approval_status text default 'pending' check (approval_status in ('pending', 'approved', 'rejected', 'fake_hidden')),
  is_available boolean default true,
  created_at timestamp default now()
);

-- 4. Wishlist / Save for later
create table wishlists (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete cascade,
  item_type text not null check (item_type in ('shop', 'product')),
  shop_id uuid references shops(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  created_at timestamp default now(),
  unique(user_id, item_type, shop_id, product_id)
);

-- 5. Report center
create table reports (
  id uuid default gen_random_uuid() primary key,
  reporter_id uuid references profiles(id) on delete set null,
  item_type text not null check (item_type in ('shop', 'product', 'comment', 'seller')),
  item_id uuid not null,
  reason text not null check (reason in ('scam', 'copyright', 'abuse', 'fake', 'other')),
  details text,
  status text default 'open' check (status in ('open', 'reviewing', 'resolved', 'rejected')),
  created_at timestamp default now()
);

-- Refund хүсэлтүүд
create table refund_requests (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete set null,
  shop_id uuid references shops(id) on delete set null,
  product_id uuid references products(id) on delete set null,
  reason text,
  amount integer,
  status text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  admin_note text,
  created_at timestamp default now(),
  decided_at timestamp
);

-- Review / comment moderation
create table comments (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete set null,
  shop_id uuid references shops(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  body text not null,
  rating integer check (rating between 1 and 5),
  is_visible boolean default true,
  created_at timestamp default now()
);

-- 6. Account deletion requests
create table account_deletion_requests (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete set null,
  email text,
  status text default 'pending' check (status in ('pending', 'completed', 'cancelled')),
  requested_at timestamp default now(),
  completed_at timestamp
);

-- 7. Audit logs
create table audit_logs (
  id uuid default gen_random_uuid() primary key,
  actor_id uuid references profiles(id) on delete set null,
  action text not null,
  target_type text,
  target_id uuid,
  metadata jsonb default '{}'::jsonb,
  created_at timestamp default now()
);

-- 8. Row Level Security идэвхжүүлэх
alter table profiles enable row level security;
alter table admin_users enable row level security;
alter table shops enable row level security;
alter table products enable row level security;
alter table wishlists enable row level security;
alter table reports enable row level security;
alter table refund_requests enable row level security;
alter table comments enable row level security;
alter table account_deletion_requests enable row level security;
alter table audit_logs enable row level security;

-- 9. Profiles policy
create policy "Өөрийн profile харах" on profiles for select using (auth.uid() = id);
create policy "Өөрийн profile засах" on profiles for insert with check (auth.uid() = id);
create policy "Өөрийн profile update" on profiles for update using (auth.uid() = id);
create policy "Өөрийн profile устгах" on profiles for delete using (auth.uid() = id);
create policy "Admin profile харах" on profiles for select using (exists (select 1 from admin_users where user_id = auth.uid()));
create policy "Admin profile update" on profiles for update using (exists (select 1 from admin_users where user_id = auth.uid()));

-- Admin users policy
create policy "Өөрийн admin эрх харах" on admin_users for select using (auth.uid() = user_id);

-- 10. Shops policy
create policy "Бүгд дэлгүүр харах" on shops for select using (true);
create policy "Эзэмшигч дэлгүүр нэмэх" on shops for insert with check (auth.uid() = owner_id);
create policy "Эзэмшигч дэлгүүр засах" on shops for update using (auth.uid() = owner_id);
create policy "Эзэмшигч дэлгүүр устгах" on shops for delete using (auth.uid() = owner_id);
create policy "Admin дэлгүүр засах" on shops for update using (exists (select 1 from admin_users where user_id = auth.uid()));
create policy "Admin дэлгүүр устгах" on shops for delete using (exists (select 1 from admin_users where user_id = auth.uid()));

-- 11. Products policy
create policy "Бүгд бараа харах" on products for select using (true);
create policy "Эзэмшигч бараа нэмэх" on products for insert with check (
  auth.uid() = (select owner_id from shops where id = shop_id)
);
create policy "Эзэмшигч бараа засах" on products for update using (
  auth.uid() = (select owner_id from shops where id = shop_id)
);
create policy "Эзэмшигч бараа устгах" on products for delete using (
  auth.uid() = (select owner_id from shops where id = shop_id)
);
create policy "Admin бараа засах" on products for update using (exists (select 1 from admin_users where user_id = auth.uid()));
create policy "Admin бараа устгах" on products for delete using (exists (select 1 from admin_users where user_id = auth.uid()));

-- 12. Wishlist policy
create policy "Өөрийн wishlist харах" on wishlists for select using (auth.uid() = user_id);
create policy "Өөрийн wishlist нэмэх" on wishlists for insert with check (auth.uid() = user_id);
create policy "Өөрийн wishlist устгах" on wishlists for delete using (auth.uid() = user_id);

-- 13. Reports policy
create policy "Report илгээх" on reports for insert with check (reporter_id is null or auth.uid() = reporter_id);
create policy "Өөрийн report харах" on reports for select using (auth.uid() = reporter_id);
create policy "Admin report харах" on reports for select using (exists (select 1 from admin_users where user_id = auth.uid()));
create policy "Admin report update" on reports for update using (exists (select 1 from admin_users where user_id = auth.uid()));

-- 14. Refund policy
create policy "Өөрийн refund харах" on refund_requests for select using (auth.uid() = user_id);
create policy "Өөрийн refund үүсгэх" on refund_requests for insert with check (auth.uid() = user_id);
create policy "Admin refund харах" on refund_requests for select using (exists (select 1 from admin_users where user_id = auth.uid()));
create policy "Admin refund update" on refund_requests for update using (exists (select 1 from admin_users where user_id = auth.uid()));

-- 15. Comments policy
create policy "Бүгд visible comment харах" on comments for select using (is_visible = true);
create policy "Өөрийн comment нэмэх" on comments for insert with check (auth.uid() = user_id);
create policy "Өөрийн comment засах" on comments for update using (auth.uid() = user_id);
create policy "Admin comment харах" on comments for select using (exists (select 1 from admin_users where user_id = auth.uid()));
create policy "Admin comment update" on comments for update using (exists (select 1 from admin_users where user_id = auth.uid()));

-- 16. Account deletion request policy
create policy "Өөрийн delete request үүсгэх" on account_deletion_requests for insert with check (auth.uid() = user_id);
create policy "Өөрийн delete request харах" on account_deletion_requests for select using (auth.uid() = user_id);
create policy "Admin delete request харах" on account_deletion_requests for select using (exists (select 1 from admin_users where user_id = auth.uid()));
create policy "Admin delete request update" on account_deletion_requests for update using (exists (select 1 from admin_users where user_id = auth.uid()));

-- 17. Audit logs policy
create policy "Өөрийн audit log харах" on audit_logs for select using (auth.uid() = actor_id);
create policy "Admin audit log харах" on audit_logs for select using (exists (select 1 from admin_users where user_id = auth.uid()));
create policy "Admin audit log нэмэх" on audit_logs for insert with check (exists (select 1 from admin_users where user_id = auth.uid()));

-- 18. Auto profile үүсгэх (бүртгүүлэхэд автоматаар)
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

