-- Qvinty v2 update.
-- Run this in Supabase SQL Editor after the first setup.sql / supabase-updates.sql.
-- After running it, add your own user id into admin_users:
-- insert into admin_users (user_id, role) values ('YOUR_AUTH_USER_ID', 'admin');

alter table profiles add column if not exists address text;
alter table profiles add column if not exists is_banned boolean default false;
alter table profiles add column if not exists deletion_requested boolean default false;

create table if not exists admin_users (
  user_id uuid references profiles(id) on delete cascade primary key,
  role text default 'admin',
  created_at timestamp default now()
);

alter table shops add column if not exists map_url text;
alter table shops add column if not exists refund_policy text;
alter table shops add column if not exists shipping_policy text;
alter table shops add column if not exists return_days integer;
alter table shops add column if not exists is_verified boolean default false;
alter table shops add column if not exists phone_verified boolean default false;
alter table shops add column if not exists email_verified boolean default false;
alter table shops add column if not exists social_verified boolean default false;

alter table products add column if not exists image_url text;
alter table products add column if not exists stock_qty integer;
alter table products add column if not exists approval_status text default 'pending';

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'products_approval_status_check'
  ) then
    alter table products add constraint products_approval_status_check
    check (approval_status in ('pending', 'approved', 'rejected', 'fake_hidden'));
  end if;
end $$;

create table if not exists wishlists (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete cascade,
  item_type text not null check (item_type in ('shop', 'product')),
  shop_id uuid references shops(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  created_at timestamp default now(),
  unique(user_id, item_type, shop_id, product_id)
);

create table if not exists reports (
  id uuid default gen_random_uuid() primary key,
  reporter_id uuid references profiles(id) on delete set null,
  item_type text not null check (item_type in ('shop', 'product', 'comment', 'seller')),
  item_id uuid not null,
  reason text not null check (reason in ('scam', 'copyright', 'abuse', 'fake', 'other')),
  details text,
  status text default 'open' check (status in ('open', 'reviewing', 'resolved', 'rejected')),
  created_at timestamp default now()
);

create table if not exists refund_requests (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete set null,
  shop_id uuid references shops(id) on delete set null,
  product_id uuid references products(id) on delete set null,
  reason text,
  amount integer,
  status text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  admin_note text,
  created_at timestamp default now(),
  decided_at timestamp
);

create table if not exists comments (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete set null,
  shop_id uuid references shops(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  body text not null,
  rating integer check (rating between 1 and 5),
  is_visible boolean default true,
  created_at timestamp default now()
);

create table if not exists account_deletion_requests (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete set null,
  email text,
  status text default 'pending' check (status in ('pending', 'completed', 'cancelled')),
  requested_at timestamp default now(),
  completed_at timestamp
);

create table if not exists audit_logs (
  id uuid default gen_random_uuid() primary key,
  actor_id uuid references profiles(id) on delete set null,
  action text not null,
  target_type text,
  target_id uuid,
  metadata jsonb default '{}'::jsonb,
  created_at timestamp default now()
);

alter table admin_users enable row level security;
alter table wishlists enable row level security;
alter table reports enable row level security;
alter table refund_requests enable row level security;
alter table comments enable row level security;
alter table account_deletion_requests enable row level security;
alter table audit_logs enable row level security;

drop policy if exists own_admin_read on admin_users;
create policy own_admin_read on admin_users for select using (auth.uid() = user_id);

drop policy if exists admin_profiles_read on profiles;
create policy admin_profiles_read on profiles for select using (exists (select 1 from admin_users where user_id = auth.uid()));
drop policy if exists admin_profiles_update on profiles;
create policy admin_profiles_update on profiles for update using (exists (select 1 from admin_users where user_id = auth.uid()));

drop policy if exists admin_shops_update on shops;
create policy admin_shops_update on shops for update using (exists (select 1 from admin_users where user_id = auth.uid()));
drop policy if exists admin_shops_delete on shops;
create policy admin_shops_delete on shops for delete using (exists (select 1 from admin_users where user_id = auth.uid()));

drop policy if exists admin_products_update on products;
create policy admin_products_update on products for update using (exists (select 1 from admin_users where user_id = auth.uid()));
drop policy if exists admin_products_delete on products;
create policy admin_products_delete on products for delete using (exists (select 1 from admin_users where user_id = auth.uid()));

drop policy if exists own_wishlists_read on wishlists;
create policy own_wishlists_read on wishlists for select using (auth.uid() = user_id);
drop policy if exists own_wishlists_insert on wishlists;
create policy own_wishlists_insert on wishlists for insert with check (auth.uid() = user_id);
drop policy if exists own_wishlists_delete on wishlists;
create policy own_wishlists_delete on wishlists for delete using (auth.uid() = user_id);

drop policy if exists own_reports_insert on reports;
create policy own_reports_insert on reports for insert with check (reporter_id is null or auth.uid() = reporter_id);
drop policy if exists own_reports_read on reports;
create policy own_reports_read on reports for select using (auth.uid() = reporter_id);
drop policy if exists admin_reports_read on reports;
create policy admin_reports_read on reports for select using (exists (select 1 from admin_users where user_id = auth.uid()));
drop policy if exists admin_reports_update on reports;
create policy admin_reports_update on reports for update using (exists (select 1 from admin_users where user_id = auth.uid()));

drop policy if exists own_refunds_read on refund_requests;
create policy own_refunds_read on refund_requests for select using (auth.uid() = user_id);
drop policy if exists own_refunds_insert on refund_requests;
create policy own_refunds_insert on refund_requests for insert with check (auth.uid() = user_id);
drop policy if exists admin_refunds_read on refund_requests;
create policy admin_refunds_read on refund_requests for select using (exists (select 1 from admin_users where user_id = auth.uid()));
drop policy if exists admin_refunds_update on refund_requests;
create policy admin_refunds_update on refund_requests for update using (exists (select 1 from admin_users where user_id = auth.uid()));

drop policy if exists public_comments_read on comments;
create policy public_comments_read on comments for select using (is_visible = true);
drop policy if exists own_comments_insert on comments;
create policy own_comments_insert on comments for insert with check (auth.uid() = user_id);
drop policy if exists own_comments_update on comments;
create policy own_comments_update on comments for update using (auth.uid() = user_id);
drop policy if exists admin_comments_read on comments;
create policy admin_comments_read on comments for select using (exists (select 1 from admin_users where user_id = auth.uid()));
drop policy if exists admin_comments_update on comments;
create policy admin_comments_update on comments for update using (exists (select 1 from admin_users where user_id = auth.uid()));

drop policy if exists own_account_delete_insert on account_deletion_requests;
create policy own_account_delete_insert on account_deletion_requests for insert with check (auth.uid() = user_id);
drop policy if exists own_account_delete_read on account_deletion_requests;
create policy own_account_delete_read on account_deletion_requests for select using (auth.uid() = user_id);
drop policy if exists admin_account_delete_read on account_deletion_requests;
create policy admin_account_delete_read on account_deletion_requests for select using (exists (select 1 from admin_users where user_id = auth.uid()));
drop policy if exists admin_account_delete_update on account_deletion_requests;
create policy admin_account_delete_update on account_deletion_requests for update using (exists (select 1 from admin_users where user_id = auth.uid()));

drop policy if exists own_audit_read on audit_logs;
create policy own_audit_read on audit_logs for select using (auth.uid() = actor_id);
drop policy if exists admin_audit_read on audit_logs;
create policy admin_audit_read on audit_logs for select using (exists (select 1 from admin_users where user_id = auth.uid()));
drop policy if exists admin_audit_insert on audit_logs;
create policy admin_audit_insert on audit_logs for insert with check (exists (select 1 from admin_users where user_id = auth.uid()));
