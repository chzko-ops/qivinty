-- Run this in Supabase SQL Editor if your original setup.sql was already applied.

alter table profiles add column if not exists address text;
alter table profiles add column if not exists deletion_requested boolean default false;

alter table shops add column if not exists map_url text;
alter table shops add column if not exists refund_policy text;
alter table shops add column if not exists shipping_policy text;
alter table shops add column if not exists return_days integer;
alter table shops add column if not exists is_verified boolean default false;
alter table shops add column if not exists phone_verified boolean default false;
alter table shops add column if not exists email_verified boolean default false;
alter table shops add column if not exists social_verified boolean default false;

alter table products add column if not exists image_url text;
alter table products add column if not exists stock_qty integer;

create table if not exists wishlists (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete cascade,
  item_type text not null check (item_type in ('shop', 'product')),
  shop_id uuid references shops(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  created_at timestamp default now(),
  unique(user_id, item_type, shop_id, product_id)
);

create table if not exists reports (
  id uuid default gen_random_uuid() primary key,
  reporter_id uuid references profiles(id) on delete set null,
  item_type text not null check (item_type in ('shop', 'product', 'comment', 'seller')),
  item_id uuid not null,
  reason text not null check (reason in ('scam', 'copyright', 'abuse', 'fake', 'other')),
  details text,
  status text default 'open' check (status in ('open', 'reviewing', 'resolved', 'rejected')),
  created_at timestamp default now()
);

create table if not exists account_deletion_requests (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete set null,
  email text,
  status text default 'pending' check (status in ('pending', 'completed', 'cancelled')),
  requested_at timestamp default now(),
  completed_at timestamp
);

create table if not exists audit_logs (
  id uuid default gen_random_uuid() primary key,
  actor_id uuid references profiles(id) on delete set null,
  action text not null,
  target_type text,
  target_id uuid,
  metadata jsonb default '{}'::jsonb,
  created_at timestamp default now()
);

alter table wishlists enable row level security;
alter table reports enable row level security;
alter table account_deletion_requests enable row level security;
alter table audit_logs enable row level security;

drop policy if exists "Өөрийн wishlist харах" on wishlists;
create policy "Өөрийн wishlist харах" on wishlists for select using (auth.uid() = user_id);
drop policy if exists "Өөрийн wishlist нэмэх" on wishlists;
create policy "Өөрийн wishlist нэмэх" on wishlists for insert with check (auth.uid() = user_id);
drop policy if exists "Өөрийн wishlist устгах" on wishlists;
create policy "Өөрийн wishlist устгах" on wishlists for delete using (auth.uid() = user_id);

drop policy if exists "Report илгээх" on reports;
create policy "Report илгээх" on reports for insert with check (reporter_id is null or auth.uid() = reporter_id);
drop policy if exists "Өөрийн report харах" on reports;
create policy "Өөрийн report харах" on reports for select using (auth.uid() = reporter_id);

drop policy if exists "Өөрийн delete request үүсгэх" on account_deletion_requests;
create policy "Өөрийн delete request үүсгэх" on account_deletion_requests for insert with check (auth.uid() = user_id);
drop policy if exists "Өөрийн delete request харах" on account_deletion_requests;
create policy "Өөрийн delete request харах" on account_deletion_requests for select using (auth.uid() = user_id);

drop policy if exists "Өөрийн audit log харах" on audit_logs;
create policy "Өөрийн audit log харах" on audit_logs for select using (auth.uid() = actor_id);
